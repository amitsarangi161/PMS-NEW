@extends('layouts.error')

@section('content')
  <div class="content">
    <div class="row">
        <h3>You are not authorized to Access This Page</h3>
        
    </div>
      
  </div>
@endsection