@extends('layouts.error')

@section('content')
  <div class="content">
    <div class="row">


        <h1>Page Not Found</h1>
        <a href="/" class="btn btn-warning">Go Back</a>
        
    </div>
      
  </div>
@endsection