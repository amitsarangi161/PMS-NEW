@extends('layouts.tender')
@section('content')

Tender Dashboard


@endsection