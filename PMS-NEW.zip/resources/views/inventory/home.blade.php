@extends('layouts.inventory')

@section('content')

    
    
@endsection

