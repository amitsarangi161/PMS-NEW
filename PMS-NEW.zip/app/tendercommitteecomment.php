<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tendercommitteecomment extends Model
{
    //
}
