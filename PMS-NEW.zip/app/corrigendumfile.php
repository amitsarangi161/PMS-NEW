<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class corrigendumfile extends Model
{
    //
}
