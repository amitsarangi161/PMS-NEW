<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invoiceno extends Model
{
    //
}
