<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class billitem extends Model
{
    //
}
