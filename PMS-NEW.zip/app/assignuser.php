<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class assignuser extends Model
{
    //
}
