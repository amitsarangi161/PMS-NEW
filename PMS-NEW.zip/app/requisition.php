<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requisition extends Model
{
    //
}
