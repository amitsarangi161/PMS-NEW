<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class deductiondefination extends Model
{
    //
}
