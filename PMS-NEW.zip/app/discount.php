<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class discount extends Model
{
    //
}
