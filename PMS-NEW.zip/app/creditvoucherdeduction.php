<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class creditvoucherdeduction extends Model
{
    //
}
