<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class expenseentrylabour extends Model
{
    //
}
