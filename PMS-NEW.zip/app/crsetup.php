<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class crsetup extends Model
{
    //
}
