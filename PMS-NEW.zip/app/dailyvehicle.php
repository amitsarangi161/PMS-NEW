<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dailyvehicle extends Model
{
    //
}
