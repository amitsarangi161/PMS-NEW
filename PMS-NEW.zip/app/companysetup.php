<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class companysetup extends Model
{
    //
}
