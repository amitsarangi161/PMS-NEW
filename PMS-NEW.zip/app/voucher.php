<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class voucher extends Model
{
    //
}
