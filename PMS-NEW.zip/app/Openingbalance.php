<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Openingbalance extends Model
{
    //
}
