<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requisitionpayment extends Model
{
    //
}
