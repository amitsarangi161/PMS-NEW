<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class projectactivity extends Model
{
    //
}
